#!/usr/bin/env python3
"""Create GitHub release using GitHub API."""

import json
import sys
from pathlib import Path

try:
    import requests
except ImportError:
    print("ERROR: 'requests' library not installed.")
    print("Install it with: pip install requests")
    sys.exit(1)

# Configuration
REPO_OWNER = "iliyaruvinsky"
REPO_NAME = "xml2sql"
TAG = "v0.1.0"
RELEASE_TITLE = "Initial Release v0.1.0"

RELEASE_NOTES = """# Initial Release v0.1.0

## 🎉 First Release

This is the initial release of the XML to SQL converter for SAP HANA calculation views.

## ✨ Features

- **Full XML Parsing**: Supports projections, joins, aggregations, unions, filters, variables, and logical models
- **Snowflake SQL Generation**: Generates valid Snowflake SQL with CTEs, proper joins, and aggregations
- **Function Translation**: Automatically translates HANA functions to Snowflake equivalents (IF→IFF, string functions, date/time)
- **Currency Conversion**: Supports currency conversion via Snowflake UDFs
- **Corporate Naming**: Template-based naming conventions for tables and views
- **Configuration Management**: YAML-based configuration with runtime overrides
- **CLI Interface**: Easy-to-use command-line interface

## 📦 Installation

```bash
git clone https://github.com/iliyaruvinsky/xml2sql.git
cd xml2sql
pip install -e ".[dev]"
```

## 🧪 Testing

- 23 unit tests (all passing)
- Regression tests for 7 XML samples
- Comprehensive manual testing completed
- 100% alignment verification: All 7 SQL files verified against source XML

## 📚 Documentation

- Comprehensive README with usage examples
- Quick start guide
- Testing documentation
- Technical documentation

## 🔧 Requirements

- Python 3.11+
- See `pyproject.toml` for dependencies

## 📝 Known Limitations

- Rank nodes not yet supported (not found in samples)
- Currency conversion via table joins not implemented (UDF-only)

## 🚀 Getting Started

See [README.md](README.md) for detailed installation and usage instructions.
"""


def create_release(token: str) -> None:
    """Create a GitHub release."""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases"
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }
    
    data = {
        "tag_name": TAG,
        "name": RELEASE_TITLE,
        "body": RELEASE_NOTES,
        "draft": False,
        "prerelease": False,
    }
    
    print(f"Creating release {TAG} for {REPO_OWNER}/{REPO_NAME}...")
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 201:
        release_data = response.json()
        print(f"✅ Release created successfully!")
        print(f"   URL: {release_data['html_url']}")
        return
    
    if response.status_code == 422:
        error_data = response.json()
        if "already exists" in str(error_data).lower():
            print(f"⚠️  Release {TAG} already exists!")
            print(f"   URL: https://github.com/{REPO_OWNER}/{REPO_NAME}/releases/tag/{TAG}")
            return
    
    print(f"❌ Error creating release: {response.status_code}")
    print(f"   Response: {response.text}")
    sys.exit(1)


def main():
    """Main function."""
    import os
    
    print("GitHub Release Creator")
    print("=" * 50)
    
    # Check for token in environment variable
    token = None
    if "GITHUB_TOKEN" in os.environ:
        token = os.environ["GITHUB_TOKEN"]
        print("✓ Found GITHUB_TOKEN environment variable")
    else:
        print("\nGitHub Personal Access Token required.")
        print("\nTo get a token:")
        print("1. Go to: https://github.com/settings/tokens")
        print("2. Click 'Generate new token (classic)'")
        print("3. Give it a name (e.g., 'xml2sql-release')")
        print("4. Select scope: 'repo' (full control of private repositories)")
        print("5. Click 'Generate token'")
        print("6. Copy the token (you won't see it again!)")
        print("\nThen run:")
        print("  set GITHUB_TOKEN=your_token_here")
        print("  python create_release.py")
        print("\nOr pass it directly:")
        token = input("\nEnter your GitHub Personal Access Token: ").strip()
    
    if not token:
        print("\n❌ No token provided. Exiting.")
        sys.exit(1)
    
    create_release(token)


if __name__ == "__main__":
    import os
    main()

