-- ============================================================================
-- Deployment Script: V_C_KMDM_MATERIALS
-- ============================================================================
-- This script creates the V_C_KMDM_MATERIALS view in Snowflake
-- 
-- Instructions:
-- 1. Replace <YOUR_SCHEMA> with your actual schema name
-- 2. Execute this script in Snowflake
-- 3. Verify the view was created: SHOW VIEWS LIKE 'V_C_KMDM_MATERIALS' IN SCHEMA <YOUR_SCHEMA>;
-- 
-- Note: This view contains warnings about joins without conditions (ON 1=1).
-- This is intentional based on the HANA calculation view definition.
-- ============================================================================

CREATE OR REPLACE VIEW <YOUR_SCHEMA>.V_C_KMDM_MATERIALS AS
-- Warnings:
--   Join Join_2 has no join conditions
--   Join Join_3 has no join conditions
--   Join Join_1 has no join conditions

WITH
  projection_5 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".MATNR AS MATNR,
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".MENGE AS MENGE,
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".MEINS AS MEINS,
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".IDNRK AS IDNRK,
        "/KMDM/CALCULATIONVIEWS/SALES_BOM".NUMGRP AS NUMGRP
    FROM "/KMDM/CALCULATIONVIEWS/SALES_BOM"
  ),
  projection_2 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS_PROD".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS_PROD".LONG_OLD_NUMBER AS LONG_OLD_NUMBER,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS_PROD".ERDAT AS ERDAT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS_PROD".MEINS AS MEINS
    FROM "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS_PROD"
  ),
  copyofprojection_1 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MATNR AS MATNR,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".ERDAT AS ERDAT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MEINS AS MEINS
    FROM "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS"
  ),
  projection_4 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MATNR AS MATNR,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MTART AS MTART,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MEINS AS MEINS,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".GEWEI AS GEWEI,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".NTGEW AS NTGEW,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".ERSDA AS ERSDA,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".LAEDA AS LAEDA,
        "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MSTAE AS MSTAE
    FROM "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS"
    WHERE "/KMDM/CALCULATIONVIEWS/MATERIAL_DETAILS".MSTAE = ''
  ),
  projection_3 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/RECENTLY_CREATED_PRODUCTS".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/RECENTLY_CREATED_PRODUCTS".MATNR AS MATNR,
        "/KMDM/CALCULATIONVIEWS/RECENTLY_CREATED_PRODUCTS".ERSDA AS ERSDA
    FROM "/KMDM/CALCULATIONVIEWS/RECENTLY_CREATED_PRODUCTS"
  ),
  projection_1 AS (
    SELECT
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MANDT AS MANDT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MATNR AS MATNR,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".ERDAT AS ERDAT,
        "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS".MEINS AS MEINS
    FROM "/KMDM/CALCULATIONVIEWS/SOLD_MATERIALS"
  ),
  join_2 AS (
    SELECT
        projection_3.MANDT AS MANDT,
        projection_3.MATNR AS MATNR,
        projection_3.ERDAT AS ERDAT,
        projection_3.MEINS AS MEINS,
        projection_3.MATNR AS MATNR,
        projection_3.MANDT AS MANDT
    FROM projection_3
    LEFT OUTER JOIN copyofprojection_1 ON 1=1
  ),
  join_3 AS (
    SELECT
        projection_5.MANDT AS MANDT,
        projection_5.MATNR AS MATNR,
        projection_5.MENGE AS MENGE,
        projection_5.MEINS AS MEINS,
        projection_5.IDNRK AS IDNRK,
        projection_5.NUMGRP AS NUMGRP,
        projection_5.ERDAT AS ERDAT,
        projection_5.MANDT AS MANDT,
        projection_5.MATNR AS MATNR
    FROM projection_5
    LEFT OUTER JOIN projection_1 ON 1=1
  ),
  union_1 AS (
    SELECT
        projection_1.MANDT AS MANDT,
        projection_1.MATNR AS MATNR,
        projection_1.MEINS AS MEINS,
        projection_1.ERDAT AS ERDAT
    FROM projection_1
    UNION ALL
    SELECT
        join_2.MANDT AS MANDT,
        join_2.MATNR AS MATNR,
        join_2.MEINS AS MEINS,
        join_2.ERDAT AS ERDAT
    FROM join_2
    UNION ALL
    SELECT
        projection_2.MANDT AS MANDT,
        projection_2.LONG_OLD_NUMBER AS MATNR,
        projection_2.MEINS AS MEINS,
        projection_2.ERDAT AS ERDAT
    FROM projection_2
    UNION ALL
    SELECT
        join_3.MANDT AS MANDT,
        join_3.IDNRK AS MATNR,
        join_3.MEINS AS MEINS,
        join_3.ERDAT AS ERDAT
    FROM join_3
  ),
  aggregation_1 AS (
    SELECT
        union_1.MANDT AS MANDT,
        union_1.MATNR AS MATNR,
        union_1.MEINS AS MEINS,
        MAX(union_1.ERDAT) AS ERDAT
    FROM union_1
    GROUP BY union_1.MANDT, union_1.MATNR, union_1.MEINS
  ),
  join_1 AS (
    SELECT
        projection_4.MTART AS MTART,
        projection_4.MEINS AS MEINS,
        projection_4.GEWEI AS GEWEI,
        projection_4.NTGEW AS NTGEW,
        projection_4.ERSDA AS ERSDA,
        projection_4.LAEDA AS LAEDA,
        projection_4.MATNR AS "JOIN$MATNR$MATNR",
        projection_4.MANDT AS "JOIN$MANDT$MANDT",
        projection_4.MATNR AS MATNR,
        projection_4.ERDAT AS ERDAT,
        projection_4.MANDT AS MANDT,
        projection_4.MATNR AS "JOIN$MATNR$MATNR",
        projection_4.MANDT AS "JOIN$MANDT$MANDT"
    FROM projection_4
    INNER JOIN aggregation_1 ON 1=1
  )

SELECT * FROM join_1;

