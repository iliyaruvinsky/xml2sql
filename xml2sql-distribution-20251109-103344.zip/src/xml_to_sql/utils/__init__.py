"""Shared utility functions."""

__all__ = []

