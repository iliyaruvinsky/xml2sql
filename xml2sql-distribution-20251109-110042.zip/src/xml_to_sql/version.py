"""Version information for XML to SQL Converter."""

__version__ = "0.2.0"

