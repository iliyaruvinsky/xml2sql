#!/usr/bin/env python3
"""Create GitHub release - tries multiple authentication methods."""

import json
import os
import sys
import subprocess

try:
    import requests
except ImportError:
    print("ERROR: 'requests' library not installed.")
    print("Install it with: pip install requests")
    sys.exit(1)

# Configuration
REPO_OWNER = "iliyaruvinsky"
REPO_NAME = "xml2sql"
TAG = "v0.1.0"
RELEASE_TITLE = "Initial Release v0.1.0"

RELEASE_NOTES = """# Initial Release v0.1.0

## 🎉 First Release

This is the initial release of the XML to SQL converter for SAP HANA calculation views.

## ✨ Features

- **Full XML Parsing**: Supports projections, joins, aggregations, unions, filters, variables, and logical models
- **Snowflake SQL Generation**: Generates valid Snowflake SQL with CTEs, proper joins, and aggregations
- **Function Translation**: Automatically translates HANA functions to Snowflake equivalents (IF→IFF, string functions, date/time)
- **Currency Conversion**: Supports currency conversion via Snowflake UDFs
- **Corporate Naming**: Template-based naming conventions for tables and views
- **Configuration Management**: YAML-based configuration with runtime overrides
- **CLI Interface**: Easy-to-use command-line interface

## 📦 Installation

```bash
git clone https://github.com/iliyaruvinsky/xml2sql.git
cd xml2sql
pip install -e ".[dev]"
```

## 🧪 Testing

- 23 unit tests (all passing)
- Regression tests for 7 XML samples
- Comprehensive manual testing completed

## 📚 Documentation

- Comprehensive README with usage examples
- Quick start guide
- Testing documentation
- Technical documentation

## 🔧 Requirements

- Python 3.11+
- See `pyproject.toml` for dependencies

## 📝 Known Limitations

- Rank nodes not yet supported (not found in samples)
- Currency conversion via table joins not implemented (UDF-only)

## 🚀 Getting Started

See [README.md](README.md) for detailed installation and usage instructions.
"""


def try_get_token_from_env():
    """Try to get token from environment variables."""
    # Check common environment variable names
    for var_name in ['GITHUB_TOKEN', 'GH_TOKEN', 'GITHUB_PAT']:
        token = os.environ.get(var_name)
        if token:
            return token
    return None


def create_release(token: str) -> bool:
    """Create a GitHub release."""
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases"
    
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }
    
    data = {
        "tag_name": TAG,
        "name": RELEASE_TITLE,
        "body": RELEASE_NOTES,
        "draft": False,
        "prerelease": False,
    }
    
    print(f"Creating release {TAG} for {REPO_OWNER}/{REPO_NAME}...")
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        
        if response.status_code == 201:
            release_data = response.json()
            print(f"✅ Release created successfully!")
            print(f"   URL: {release_data['html_url']}")
            return True
        
        if response.status_code == 422:
            error_data = response.json()
            if "already exists" in str(error_data).lower():
                print(f"⚠️  Release {TAG} already exists!")
                print(f"   URL: https://github.com/{REPO_OWNER}/{REPO_NAME}/releases/tag/{TAG}")
                return True
        
        print(f"❌ Error creating release: {response.status_code}")
        print(f"   Response: {response.text}")
        return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def main():
    """Main function."""
    print("GitHub Release Creator (Auto)")
    print("=" * 50)
    
    # Try to get token from environment
    token = try_get_token_from_env()
    
    if token:
        print("✓ Found GitHub token in environment")
        if create_release(token):
            return
        else:
            print("\n⚠️  Token found but release creation failed.")
            print("   The token might not have the right permissions.")
    
    # If we get here, we need user to provide token
    print("\n" + "=" * 50)
    print("GitHub Personal Access Token required.")
    print("\nTo get a token:")
    print("1. Go to: https://github.com/settings/tokens")
    print("2. Click 'Generate new token (classic)'")
    print("3. Give it a name (e.g., 'xml2sql-release')")
    print("4. Select scope: 'repo' (full control of private repositories)")
    print("5. Click 'Generate token'")
    print("6. Copy the token")
    print("\nThen set it as environment variable:")
    print("  set GITHUB_TOKEN=your_token_here")
    print("  python create_release_auto.py")
    print("\nOr create the release manually on GitHub:")
    print(f"  https://github.com/{REPO_OWNER}/{REPO_NAME}/releases/new")
    
    sys.exit(1)


if __name__ == "__main__":
    main()

