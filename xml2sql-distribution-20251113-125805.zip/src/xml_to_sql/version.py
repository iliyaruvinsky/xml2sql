"""Version information for XML to SQL Converter."""

__version__ = "2.2.0"

