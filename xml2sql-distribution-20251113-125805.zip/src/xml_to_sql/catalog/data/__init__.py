"""Resource package for catalog data files."""

