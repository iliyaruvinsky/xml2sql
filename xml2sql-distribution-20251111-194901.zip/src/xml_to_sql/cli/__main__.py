"""CLI entry point for running as a module."""

from .app import app

if __name__ == "__main__":
    app()

