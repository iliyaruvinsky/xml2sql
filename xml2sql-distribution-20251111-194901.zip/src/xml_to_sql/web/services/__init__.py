"""Service layer for web interface."""

__all__ = []

