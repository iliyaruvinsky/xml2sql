#!/usr/bin/env python3
"""Check if release exists, create if not."""

import requests
import sys

REPO_OWNER = "iliyaruvinsky"
REPO_NAME = "xml2sql"
TAG = "v0.1.0"

# Check if release already exists (no auth needed for public repos)
print(f"Checking if release {TAG} already exists...")
try:
    response = requests.get(
        f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases/tags/{TAG}",
        timeout=10
    )
    
    if response.status_code == 200:
        release_data = response.json()
        print(f"✅ Release already exists!")
        print(f"   URL: {release_data['html_url']}")
        print(f"   Title: {release_data['name']}")
        sys.exit(0)
    elif response.status_code == 404:
        print(f"ℹ️  Release {TAG} does not exist yet.")
        print(f"\nTo create it, you need a GitHub Personal Access Token.")
        print(f"Then run: python create_release_auto.py")
        print(f"\nOr create it manually:")
        print(f"  https://github.com/{REPO_OWNER}/{REPO_NAME}/releases/new")
    else:
        print(f"⚠️  Unexpected status: {response.status_code}")
        print(f"   Response: {response.text}")
        
except Exception as e:
    print(f"❌ Error checking release: {e}")
    print(f"\nYou can check manually:")
    print(f"  https://github.com/{REPO_OWNER}/{REPO_NAME}/releases")

